// oxlint-disable max-lines-per-function, no-magic-numbers
// Copyright (C) 2025 - present Juergen Zimmermann, Hochschule Karlsruhe
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program. If not, see <https://www.gnu.org/licenses/>.

import { type AxiosResponse, HttpStatusCode } from 'axios';
import { CONTENT_TYPE, restURL } from '../constants.mts';
import { describe, expect, test } from 'vitest';
import { type BuchDTO } from '../../../src/buch/service/buch-dto.mts';
import { type Page } from '../../../src/buch/router/page.mts';
import { client } from './client.mts';

type BuchType = Omit<BuchDTO, 'preis' | 'rabatt'> & {
    preis: string;
    rabatt: string;
};

// -----------------------------------------------------------------------------
// T e s t d a t e n
// -----------------------------------------------------------------------------
const titelArray = ['a', 'l', 't'];
const titelNichtVorhanden = ['xxx', 'yyy', 'zzz'];
const isbns = ['978-3-897-22583-1', '978-3-827-31552-6', '978-0-201-63361-0'];
const ratingMin = [3, 4];
const preisMax = [33.5, 66.6];
const schlagwoerter = ['javascript', 'typescript'];
const schlagwoerterNichtVorhanden = ['csharp', 'cobol'];

// -----------------------------------------------------------------------------
// T e s t s
// -----------------------------------------------------------------------------
// Test-Suite
describe('GET /rest', () => {
    test.concurrent('Alle Buecher', async () => {
        // given
        // when
        const { data, headers, status }: AxiosResponse<Page<BuchType>> = await client.get('');

        // then
        expect(status).toBe(HttpStatusCode.Ok);
        expect(headers[CONTENT_TYPE]).toMatch(/json/iu);

        data.content
            .map((buch) => buch.id)
            .forEach((id) => {
                expect(id).toBeDefined();
            });
    });

    test.concurrent.each(titelArray)('Buecher mit Teil-Titel %s suchen', async (titel) => {
        // given
        const params = new URLSearchParams({ titel });
        const url = `${restURL}?${params}`;

        // when
        const { data, headers, status }: AxiosResponse<Page<BuchType>> = await client.get(url);

        // then
        expect(status).toBe(HttpStatusCode.Ok);
        expect(headers[CONTENT_TYPE]).toMatch(/json/iu);

        expect(data).toBeDefined();

        // Jedes Buch hat einen Titel mit dem Teilstring
        data.content
            .map((buch) => buch.titel)
            .forEach((tit) =>
                expect(tit?.titel?.toLowerCase()).toStrictEqual(expect.stringContaining(titel)),
            );
    });

    test.concurrent.each(titelNichtVorhanden)(
        'Buecher zu nicht vorhandenem Teil-Titel %s suchen',
        async (titel) => {
            // given
            const params = new URLSearchParams({ titel });
            const url = `${restURL}?${params}`;

            // when
            const { status } = await client.get(url);

            // then
            expect(status).toBe(HttpStatusCode.NotFound);
        },
    );

    test.concurrent.each(isbns)('Buch mit ISBN %s suchen', async (isbn) => {
        // given
        const params = new URLSearchParams({ isbn });
        const url = `${restURL}?${params}`;

        // when
        const { data, headers, status }: AxiosResponse<Page<BuchType>> = await client.get(url);

        // then
        expect(status).toBe(HttpStatusCode.Ok);
        expect(headers[CONTENT_TYPE]).toMatch(/json/iu);

        expect(data).toBeDefined();

        // 1 Buch mit der ISBN
        const buecher = data.content;

        expect(buecher).toHaveLength(1);

        const [buch] = buecher;
        const isbnFound = buch?.isbn;

        expect(isbnFound).toBe(isbn);
    });

    test.concurrent.each(ratingMin)('Buecher mit Mindest-"rating" %i suchen', async (rating) => {
        // given
        const params = new URLSearchParams({ rating: rating.toString() });
        const url = `${restURL}?${params}`;

        // when
        const { data, headers, status }: AxiosResponse<Page<BuchType>> = await client.get(url);

        // then
        expect(status).toBe(HttpStatusCode.Ok);
        expect(headers[CONTENT_TYPE]).toMatch(/json/iu);

        // Jedes Buch hat eine Bewertung >= rating
        data.content
            .map((buch) => buch.rating)
            .forEach((rat) => expect(rat).toBeGreaterThanOrEqual(rating));
    });

    test.concurrent.each(preisMax)('Buecher mit max. Preis %d suchen', async (preis) => {
        // given
        const params = new URLSearchParams({ preis: preis.toString() });
        const url = `${restURL}?${params}`;

        // when
        const { data, status, headers }: AxiosResponse<Page<BuchType>> = await client.get(url);

        // then
        expect(status).toBe(HttpStatusCode.Ok);
        expect(headers[CONTENT_TYPE]).toMatch(/json/iu);

        // Jedes Buch hat einen Preis <= preis
        data.content
            .map((buch) => buch?.preis ?? 0)
            .forEach((pr) => expect(Number(pr)).toBeLessThanOrEqual(preis));
    });

    test.concurrent.each(schlagwoerter)('Mind. 1 Buch mit Schlagwort %s', async (schlagwort) => {
        // given
        const params = new URLSearchParams({ [schlagwort]: 'true' });
        const url = `${restURL}?${params}`;

        // when
        const { data, status, headers }: AxiosResponse<Page<BuchType>> = await client.get(url);

        // then
        expect(status).toBe(HttpStatusCode.Ok);
        expect(headers[CONTENT_TYPE]).toMatch(/json/iu);

        // JSON-Array mit mind. 1 JSON-Objekt
        expect(data).toBeDefined();

        // Jedes Buch hat im Array der Schlagwoerter z.B. "javascript"
        data.content
            .map((buch) => buch.schlagwoerter)
            .forEach((sw) =>
                expect(sw).toStrictEqual(expect.arrayContaining([schlagwort.toUpperCase()])),
            );
    });

    test.concurrent.each(schlagwoerterNichtVorhanden)(
        'Keine Buecher zu einem nicht vorhandenen Schlagwort',
        async (schlagwort) => {
            const params = new URLSearchParams({ [schlagwort]: 'true' });
            const url = `${restURL}?${params}`;

            // when
            const { status } = await client.get(url);

            // then
            expect(status).toBe(HttpStatusCode.NotFound);
        },
    );

    test.concurrent('Keine Buecher zu einer nicht-vorhandenen Property', async () => {
        // given
        const params = new URLSearchParams({ foo: 'bar' });
        const url = `${restURL}?${params}`;

        // when
        const { status } = await client.get(url);

        // then
        expect(status).toBe(HttpStatusCode.NotFound);
    });
});
