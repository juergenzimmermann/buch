// oxlint-disable max-lines, max-lines-per-function, no-magic-numbers
// Copyright (C) 2025 - present Juergen Zimmermann, Hochschule Karlsruhe
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program. If not, see <https://www.gnu.org/licenses/>.

import { type AxiosResponse, HttpStatusCode } from 'axios';
import { describe, expect, test } from 'vitest';
import { type Buch } from '../../../src/buch/graphql/types.mts';
import { type Buchart } from '../../../src/buch/service/suchparameter.mts';
import { CONTENT_TYPE } from '../constants.mts';
import { type GraphQLQuery } from './graphql.mts';
import { client } from './client.mts';

type BuchSuccessType = { data: { buch: Buch }; errors?: undefined };
type BuecherSuccessType = { data: { buecher: Buch[] }; errors?: undefined };

export type ErrorsType = {
    message: string;
    path: string[];
    extensions: { code: string };
}[];
type BuchErrorsType = { data: { buch: null }; errors: ErrorsType };
type BuecherErrorsType = { data: { buecher: null }; errors: ErrorsType };

// -----------------------------------------------------------------------------
// T e s t d a t e n
// -----------------------------------------------------------------------------
const ids = [1, 20];

const titelArray = ['a', 'l', 't'];
const titelNichtVorhanden = ['xxx', 'yyy', 'zzz'];
const isbns = ['978-3-897-22583-1', '978-3-827-31552-6', '978-0-201-63361-0'];
const ratingMin = [3, 4];
const ratingNichtVorhanden = 99;

// -----------------------------------------------------------------------------
// T e s t s
// -----------------------------------------------------------------------------
// Test-Suite
describe('GraphQL Queries', () => {
    test.concurrent.each(ids)('Buch zu ID %i', async (id) => {
        // given
        const query: GraphQLQuery = {
            query: `
                {
                    buch(id: "${id}") {
                        version
                        isbn
                        rating
                        art
                        preis
                        lieferbar
                        datum
                        homepage
                        schlagwoerter
                        titel {
                            titel
                        }
                        rabatt
                    }
                }
            `,
        };

        // when
        const response: AxiosResponse<BuchSuccessType> = await client.post('', query);

        // then
        const { data, status } = response;

        expect(status).toBe(HttpStatusCode.Ok);
        expect(response.headers[CONTENT_TYPE]).toMatch(/application\/graphql-response\+json/iu);

        const { errors } = data;

        expect(errors).toBeUndefined();

        const graphQLData = data.data;

        expect(graphQLData).toBeDefined();

        const { buch } = graphQLData;

        expect(buch.titel?.titel).toMatch(/^\w/u);
        expect(buch.version).toBeGreaterThan(-1);
        expect(buch.id).toBeUndefined();
    });

    test.concurrent('Buch zu nicht-vorhandener ID', async () => {
        // given
        const id = '999999';
        const query: GraphQLQuery = {
            query: `
                {
                    buch(id: "${id}") {
                        titel {
                            titel
                        }
                    }
                }
            `,
        };

        // when
        const response: AxiosResponse<BuchErrorsType> = await client.post('', query);

        // then
        const { data, status } = response;

        expect(status).toBe(HttpStatusCode.Ok);
        expect(response.headers[CONTENT_TYPE]).toMatch(/application\/graphql-response\+json/iu);
        expect(data.data).toBeNull();

        const { errors } = data;

        expect(errors).toHaveLength(1);

        const [error] = errors;
        const { message, path, extensions } = error!;

        expect(message).toBe(`Es gibt kein Buch mit der ID ${id}.`);
        expect(path).toBeDefined();
        expect(path![0]).toBe('buch');
        expect(extensions).toBeDefined();
        expect(extensions!.code).toBe('BAD_USER_INPUT');
    });

    test.concurrent.each(titelArray)('Buecher zu Teil-Titel %s', async (titel) => {
        // given
        const query: GraphQLQuery = {
            query: `
                    {
                        buecher(input: {
                            titel: "${titel}"
                        }) {
                            titel {
                                titel
                            }
                        }
                    }
                `,
        };

        // when
        const response: AxiosResponse<BuecherSuccessType> = await client.post('', query);

        // then
        const { data, status } = response;

        expect(status).toBe(HttpStatusCode.Ok);
        expect(response.headers[CONTENT_TYPE]).toMatch(/application\/graphql-response\+json/iu);

        const { errors } = data;

        expect(errors).toBeUndefined();

        const graphQlData = data.data;

        expect(graphQlData).toBeDefined();

        const { buecher } = graphQlData;

        expect(buecher).not.toHaveLength(0);

        buecher
            .map((buch) => buch.titel)
            .forEach((tit) =>
                expect(tit?.titel?.toLowerCase()).toStrictEqual(expect.stringContaining(titel)),
            );
    });

    test.concurrent.each(titelNichtVorhanden)(
        'Buch zu nicht vorhandenem Titel %s',
        async (titel) => {
            // given
            const query: GraphQLQuery = {
                query: `
                    {
                        buecher(input: {
                            titel: "${titel}"
                        }) {
                            art
                            titel {
                                titel
                            }
                        }
                    }
                `,
            };

            // when
            const response: AxiosResponse<BuecherErrorsType> = await client.post('', query);

            // then
            const { data, status } = response;

            expect(status).toBe(HttpStatusCode.Ok);
            expect(response.headers[CONTENT_TYPE]).toMatch(/application\/graphql-response\+json/iu);
            expect(data.data).toBeNull();

            const { errors } = data;

            expect(errors).toHaveLength(1);

            const [error] = errors;
            const { message, path, extensions } = error!;

            expect(message).toMatch(/^Keine Buecher gefunden:/u);
            expect(path).toBeDefined();
            expect(path![0]).toBe('buecher');
            expect(extensions).toBeDefined();
            expect(extensions!.code).toBe('BAD_USER_INPUT');
        },
    );

    test.concurrent.each(isbns)('Buch zu ISBN-Nummer %s', async (isbnExpected) => {
        // given
        const query: GraphQLQuery = {
            query: `
                    {
                        buecher(input: {
                            isbn: "${isbnExpected}"
                        }) {
                            isbn
                            titel {
                                titel
                            }
                        }
                    }
                `,
        };

        // when
        const response: AxiosResponse<BuecherSuccessType> = await client.post('', query);

        // then
        const { data, status } = response;

        expect(status).toBe(HttpStatusCode.Ok);
        expect(response.headers[CONTENT_TYPE]).toMatch(/application\/graphql-response\+json/iu);

        const { errors } = data;

        expect(errors).toBeUndefined();

        const graphQlData = data.data;

        expect(graphQlData).toBeDefined();

        const { buecher } = graphQlData;

        expect(buecher).not.toHaveLength(0);
        expect(buecher).toHaveLength(1);

        const [buch] = buecher;
        const { titel, isbn } = buch!;

        expect(isbn).toBe(isbnExpected);
        expect(titel?.titel).toBeDefined();
    });

    test.concurrent.each(ratingMin)('Buecher mit Mindest-"rating" %i', async (ratingExpected) => {
        // given
        const teilTitel = 'a';
        const query: GraphQLQuery = {
            query: `
                    {
                        buecher(input: {
                            rating: ${ratingExpected},
                            titel: "${teilTitel}"
                        }) {
                            rating
                            titel {
                                titel
                            }
                        }
                    }
                `,
        };

        // when
        const response: AxiosResponse<BuecherSuccessType> = await client.post('', query);

        // then
        const { data, status } = response;

        expect(status).toBe(HttpStatusCode.Ok);
        expect(response.headers[CONTENT_TYPE]).toMatch(/application\/graphql-response\+json/iu);

        const { errors } = data;

        expect(errors).toBeUndefined();

        const graphQlData = data.data;

        expect(graphQlData).toBeDefined();

        const { buecher } = graphQlData;

        expect(buecher).not.toHaveLength(0);

        buecher.forEach((buch) => {
            const { rating, titel } = buch;

            expect(rating).toBeGreaterThanOrEqual(ratingExpected);
            expect(titel?.titel?.toLowerCase()).toStrictEqual(expect.stringContaining(teilTitel));
        });
    });

    test.concurrent('Kein Buch zu nicht-vorhandenem "rating"', async () => {
        // given
        const query: GraphQLQuery = {
            query: `
                {
                    buecher(input: {
                        rating: ${ratingNichtVorhanden}
                    }) {
                        titel {
                            titel
                        }
                    }
                }
            `,
        };

        // when
        const response: AxiosResponse<BuecherErrorsType> = await client.post('', query);

        // then
        const { data, status } = response;

        expect(status).toBe(HttpStatusCode.Ok);
        expect(response.headers[CONTENT_TYPE]).toMatch(/application\/graphql-response\+json/iu);
        expect(data.data).toBeNull();

        const { errors } = data;

        expect(errors).toHaveLength(1);

        const [error] = errors;
        const { message, path, extensions } = error!;

        expect(message).toMatch(/^Keine Buecher gefunden:/u);
        expect(path).toBeDefined();
        expect(path![0]).toBe('buecher');
        expect(extensions).toBeDefined();
        expect(extensions!.code).toBe('BAD_USER_INPUT');
    });

    test.concurrent('Buecher zur Art "EPUB"', async () => {
        // given
        const buchArt: Buchart = 'EPUB';
        const query: GraphQLQuery = {
            query: `
                {
                    buecher(input: {
                        art: ${buchArt}
                    }) {
                        art
                        titel {
                            titel
                        }
                    }
                }
            `,
        };

        // when
        const response: AxiosResponse<BuecherSuccessType> = await client.post('', query);

        // then
        const { data, status } = response;

        expect(status).toBe(HttpStatusCode.Ok);
        expect(response.headers[CONTENT_TYPE]).toMatch(/application\/graphql-response\+json/iu);

        const { errors } = data;

        expect(errors).toBeUndefined();

        const graphQlData = data.data;

        expect(graphQlData).toBeDefined();

        const { buecher } = graphQlData;

        expect(buecher).not.toHaveLength(0);

        buecher.forEach((buch) => {
            const { art, titel } = buch;

            expect(art).toBe(buchArt);
            expect(titel?.titel).toBeDefined();
        });
    });

    test.concurrent('Buecher zur einer ungueltigen Art', async () => {
        // given
        const buchArt = 'UNGUELTIG';
        const query: GraphQLQuery = {
            query: `
                {
                    buecher(input: {
                        art: ${buchArt}
                    }) {
                        titel {
                            titel
                        }
                    }
                }
            `,
        };

        // when
        const response: AxiosResponse<BuecherErrorsType> = await client.post('', query);

        // then
        const { data, status } = response;

        expect(status).toBe(HttpStatusCode.BadRequest);
        expect(response.headers[CONTENT_TYPE]).toMatch(/application\/graphql-response\+json/iu);
        expect(data.data).toBeUndefined();

        const { errors } = data;

        expect(errors).toHaveLength(1);

        const [error] = errors;
        const { extensions } = error!;

        expect(extensions).toBeDefined();
        expect(extensions!.code).toBe('GRAPHQL_VALIDATION_FAILED');
    });

    test.concurrent('Buecher mit lieferbar=true', async () => {
        // given
        const query: GraphQLQuery = {
            query: `
                {
                    buecher(input: {
                        lieferbar: true
                    }) {
                        lieferbar
                        titel {
                            titel
                        }
                    }
                }
            `,
        };

        // when
        const response: AxiosResponse<BuecherSuccessType> = await client.post('', query);

        // then
        const { data, status } = response;

        expect(status).toBe(HttpStatusCode.Ok);
        expect(response.headers[CONTENT_TYPE]).toMatch(/application\/graphql-response\+json/iu);

        const { errors } = data;

        expect(errors).toBeUndefined();

        const graphQlData = data.data;

        expect(graphQlData).toBeDefined();

        const { buecher } = graphQlData;

        expect(buecher).not.toHaveLength(0);

        buecher.forEach((buch) => {
            const { lieferbar, titel } = buch;

            expect(lieferbar).toBe(true);
            expect(titel?.titel).toBeDefined();
        });
    });
});
