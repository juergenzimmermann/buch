// Copyright (C) 2024 - present Juergen Zimmermann, Hochschule Karlsruhe
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program. If not, see <https://www.gnu.org/licenses/>.

import { type Pageable } from '../service/pageable.mts';
import { type Slice } from '../service/slice.mts';

export type Page<T> = {
    readonly content: T[];
    readonly page: {
        readonly size: number;
        readonly number: number;
        readonly totalElements: number;
        readonly totalPages: number;
    };
};

// oxlint-disable-next-line func-style
export function createPage<T>(slice: Slice<T>, pageable: Pageable): Page<T> {
    const { content, totalElements } = slice;
    const { size, number } = pageable;
    return {
        content,
        page: {
            size,
            number,
            totalElements,
            totalPages: Math.ceil(totalElements / size),
        },
    };
}
