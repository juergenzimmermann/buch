// oxlint-disable max-lines, max-dependencies
// Copyright (C) 2016 - present Juergen Zimmermann, Hochschule Karlsruhe
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program. If not, see <https://www.gnu.org/licenses/>.

/**
 * Das Modul besteht aus Funktionen für die Suche nach Büchern.
 * @packageDocumentation
 */

import { BuchDTO, type BuchSelect } from './buch-dto.mts';
import { type Suchparameter, suchparameterNamen } from './suchparameter.mts';
import { abbildungTable, buchFileTable, buchTable, titelTable } from '../../db/schema.mts';
import { count, eq } from 'drizzle-orm';
import { type AbbildungSelect } from './abbildung-dto.mts';
import { NotFoundError } from './errors.mts';
import { type Pageable } from './pageable.mts';
import { type Slice } from './slice.mts';
import { type TitelSelect } from './titel-dto.mts';
import { buildWhere } from './build-where.mts';
import { db } from '../../config/db.mts';
import { getLogger } from '../../logger/logger.mts';

// Rueckgabetyp Promise bei asynchronen Funktionen
//    ab ES2015
//    vergleiche Task<> bei C#
// Status eines Promise:
//    Pending:   das Resultat ist noch nicht vorhanden, weil die asynchrone
//               Operation noch nicht abgeschlossen ist
//    Fulfilled: die asynchrone Operation ist abgeschlossen und
//               das Promise-Objekt hat einen Wert
//    Rejected:  die asynchrone Operation ist fehlgeschlagen and das
//               Promise-Objekt wird nicht den Status "fulfilled" erreichen.
//               Im Promise-Objekt ist dann die Fehlerursache enthalten.

type BuchMitTitelSelect = { buch: BuchSelect; titel: TitelSelect };
type BuchMitTitelUndAbbildungSelect = BuchMitTitelSelect & {
    abbildung: AbbildungSelect;
};

const logger = getLogger('buch-service');

/**
 * Ein Buch asynchron anhand seiner ID suchen und den Titel mitladen
 * @param id ID des gesuchten Buches
 * @returns Das gefundene Buch in einem Promise.
 * @throws NotFoundError falls kein Buch mit der ID existiert
 */
export const findById = async (id: number): Promise<Readonly<BuchDTO>> => {
    logger.debug('findById: id=%d', id);

    // Lesen: Keine Transaktion erforderlich
    const [row]: BuchMitTitelSelect[] = await db
        .select()
        .from(buchTable)
        .innerJoin(titelTable, eq(buchTable.id, titelTable.buchId))
        .where(eq(buchTable.id, id))
        .limit(1);

    if (row === undefined) {
        logger.debug('Es gibt kein Buch mit der ID %d', id);
        throw new NotFoundError(`Es gibt kein Buch mit der ID ${id}.`);
    }

    const buchDTO: BuchDTO = new BuchDTO(row.buch, row.titel);

    logger.debug('findById: buchDTO=%o', buchDTO);
    return buchDTO;
};

/**
 * Ein Buch asynchron anhand seiner ID suchen und den Titel und die Abbildungen mitladen
 * @param id ID des gesuchten Buches
 * @returns Das gefundene Buch in einem Promise.
 * @throws NotFoundError falls kein Buch mit der ID existiert
 */
export const findByIdMitAbb = async (id: number): Promise<Readonly<BuchDTO>> => {
    logger.debug('findByIdMitAbb: id=%d', id);

    const rows: BuchMitTitelUndAbbildungSelect[] = await db
        .select()
        .from(buchTable)
        .innerJoin(titelTable, eq(buchTable.id, titelTable.buchId))
        .innerJoin(abbildungTable, eq(buchTable.id, abbildungTable.buchId))
        .where(eq(buchTable.id, id));

    if (rows.length === 0) {
        logger.debug('Es gibt kein Buch mit der ID %d', id);
        throw new NotFoundError(`Es gibt kein Buch mit der ID ${id}.`);
    }

    // jeder Datensatz enthaelt das gefundene Buch
    const [firstRow] = rows;
    if (firstRow === undefined) {
        logger.debug('Interner Fehler bei der Suche mit der ID %d', id);
        throw new NotFoundError(`Es gibt kein Buch mit der ID ${id}.`);
    }

    // Abbildungen als JSON-Array fuer das eine gefundene Buch
    const abbildungRows = rows.filter((row) => row !== undefined).map((row) => row.abbildung);

    const buchDTO: BuchDTO = new BuchDTO(firstRow.buch, firstRow.titel, abbildungRows);
    logger.debug('findByIdMitAbb: buchDTO=%o', buchDTO);
    return buchDTO;
};

/**
 * Die Version zu gegebener ID ermitteln.
 * @param id ID des gesuchten Buches
 * @returns Die Version in einem Promise.
 * @throws NotFoundError falls kein Buch mit der ID existiert
 */
export const findVersionById = async (id: number): Promise<number> => {
    logger.debug('findVersionById: id=%d', id);

    const [row]: { version: number }[] = await db
        .select({ version: buchTable.version })
        .from(buchTable)
        .where(eq(buchTable.id, id))
        .limit(1);

    if (row === undefined) {
        logger.debug('Es gibt kein Buch mit der ID %d', id);
        throw new NotFoundError(`Es gibt kein Buch mit der ID ${id}.`);
    }

    const { version } = row;
    logger.debug('findVersionById: version=%d', version);
    return version;
};

/**
 * Gibt es ein Buch zur gegebenen ID
 * @param id ID des gesuchten Buches
 * @returns true in einem Promise, falls das Buch existiert, sonst false.
 */
export const existsById = async (id: number): Promise<boolean> => {
    logger.debug('existsById: id=%d', id);

    const [row]: { id: number }[] = await db
        .select({ id: buchTable.id })
        .from(buchTable)
        .where(eq(buchTable.id, id))
        .limit(1);

    if (row === undefined) {
        logger.debug('existsById: false');
        return false;
    }

    logger.debug('existsById: true');
    return true;
};

export const createSlice = (
    buecher: BuchDTO[],
    totalElements: number,
): Readonly<Slice<BuchDTO>> => {
    const buchSlice: Slice<BuchDTO> = {
        content: buecher,
        totalElements,
    };
    logger.debug('createSlice: buchSlice=%o', buchSlice);
    return buchSlice;
};

export const findAll = async (pageable: Pageable): Promise<Readonly<Slice<BuchDTO>>> => {
    const { number, size } = pageable;
    const rows: BuchMitTitelSelect[] = await db
        .select()
        .from(buchTable)
        .innerJoin(titelTable, eq(buchTable.id, titelTable.buchId))
        .offset(number * size)
        .limit(size);
    const totalElements = rows.length;
    if (totalElements === 0) {
        logger.debug('#findAll: Keine Buecher gefunden');
        throw new NotFoundError(`Ungueltige Seite "${number}"`);
    }
    const buecher = rows.map((row) => new BuchDTO(row.buch, row.titel));
    return createSlice(buecher, totalElements);
};

export const checkKeys = (keys: string[]) => {
    logger.debug('#checkKeys: keys=%o', keys);
    // Ist jeder Suchparameter auch eine Property von Buch oder "schlagwoerter"?
    let validKeys = true;
    keys.forEach((key) => {
        if (
            !suchparameterNamen.includes(key) &&
            key !== 'javascript' &&
            key !== 'typescript' &&
            key !== 'java' &&
            key !== 'python'
        ) {
            logger.debug('#checkKeys: ungueltiger Suchparameter "%s"', key);
            validKeys = false;
        }
    });

    return validKeys;
};

export const checkEnums = (suchparameter: Suchparameter) => {
    const { art } = suchparameter;
    logger.debug('#checkEnums: Suchparameter "art=%s"', art);
    return art === undefined || art === 'EPUB' || art === 'HARDCOVER' || art === 'PAPERBACK';
};

/**
 * Bücher asynchron suchen.
 * @param suchparameter JSON-Objekt mit Suchparameter.
 * @param pageable Maximale Anzahl an Datensätzen und Seitennummer.
 * @returns Ein JSON-Array mit den gefundenen Büchern.
 * @throws NotFoundError falls keine Bücher gefunden wurden.
 */
export const find = async (
    suchparameter: Record<string, string | undefined>,
    pageable: Pageable,
): Promise<Readonly<Slice<Readonly<BuchDTO>>>> => {
    logger.debug('find: suchparameter=%s, pageable=%o', JSON.stringify(suchparameter), pageable);

    // Keine Suchparameter?
    const keys = Object.keys(suchparameter);
    if (keys.length === 0) {
        return await findAll(pageable);
    }

    // Falsche Namen fuer Suchparameter?
    if (!checkKeys(keys) || !checkEnums(suchparameter)) {
        logger.debug('Ungueltige Suchparameter');
        throw new NotFoundError('Ungueltige Suchparameter');
    }

    const where = buildWhere(suchparameter as Suchparameter);
    const { number, size } = pageable;

    // Das Resultat ist eine leere Liste, falls nichts gefunden
    // Lesen: Keine Transaktion erforderlich
    const rows: BuchMitTitelSelect[] = await db
        .select()
        .from(buchTable)
        .innerJoin(titelTable, eq(buchTable.id, titelTable.buchId))
        .where(where)
        .offset(number * size)
        .limit(size);
    if (rows.length === 0) {
        logger.debug('find: Keine Buecher gefunden');
        throw new NotFoundError(
            `Keine Buecher gefunden: ${JSON.stringify(suchparameter)}, Seite ${pageable.number}}`,
        );
    }

    const buecher = rows.map((row) => new BuchDTO(row.buch, row.titel));
    const [total] = await db
        .select({ count: count() })
        .from(buchTable)
        .innerJoin(titelTable, eq(buchTable.id, titelTable.buchId))
        .where(where);
    return createSlice(buecher, total?.count ?? 0);
};

export type BuchFileSelect = typeof buchFileTable.$inferSelect;

/**
 * Binärdatei zu einem Buch suchen.
 * @param buchId ID des zugehörigen Buchs.
 * @returns Binärdatei oder undefined als Promise.
 */
export const findFileByBuchId = async (
    buchId: number,
): Promise<Readonly<BuchFileSelect> | undefined> => {
    logger.debug('findFileByBuchId: buchId=%d', buchId);
    const [buchFile]: BuchFileSelect[] = await db
        .select()
        .from(buchFileTable)
        .where(eq(buchFileTable.buchId, buchId))
        .limit(1);
    if (buchFile === undefined) {
        logger.debug('findFileByBuchId: Keine Datei gefunden');
        return;
    }

    logger.debug(
        'findFileByBuchId: id=%s, byteLength=%d, filename=%s, mimetype=%s, buchId=%d',
        buchFile.id,
        (buchFile.data as Uint8Array<ArrayBuffer>).byteLength,
        buchFile.filename,
        buchFile.mimetype,
        buchFile.buchId,
    );

    // als Datei im Wurzelverzeichnis des Projekts speichern:
    // import { writeFile } from 'node:fs/promises';
    // await writeFile(buchFile.filename, buchFile.data);

    return buchFile;
};
