// Copyright (C) 2026 - present Juergen Zimmermann, Hochschule Karlsruhe
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program. If not, see <http://www.gnu.org/licenses/>.

// Alternativen zu Zod:
//      ajv -> JSON schema statt TypeScript-Code
//      valibot <- Bachelorthesis an der HdM Stuttgart mit Miško Hevery (→ Angular) als Zweitbetreuer
//      arktype
//      joi von Hapi
//      class-validator (ursprüngl. in Nest integriert)
//      ata-validator (evtl. in Node und Bun integriert)

import { AbbildungSchema } from './abbildung-validation.mts';
import ISBN from 'isbn3';
import { TitelSchema } from './titel-validation.mts';
import { z } from 'zod';

export const MAX_RATING = 5;

const BuchSchema = z.strictObject({
    // bei GraphQL ist der Typ ID i.a. ein String
    id: z.union([z.number().int().gt(0), z.string().regex(/^[1-9]\d*$/u)]),
    version: z.int().gte(0),
    isbn: z.string().refine((isbnStr) => ISBN.parse(isbnStr)?.isValid === true, {
        message: 'Ungültige ISBN-Nummer',
    }),
    rating: z.int().gte(0).lte(MAX_RATING),
    art: z.enum(['EPUB', 'HARDCOVER', 'PAPERBACK']).optional(),
    preis: z.number().gte(0),
    rabatt: z.number().gt(0).lt(1).optional(),
    lieferbar: z.boolean().optional(),
    // TODO Zod verwendet den Konstruktor von Date, so dass 2025-02-30 zu 2025-03-02 wird
    datum: z.coerce.date().optional(),
    homepage: z.httpUrl().optional(),
    schlagwoerter: z.array(z.string()).optional(),

    titel: TitelSchema,
    abbildungen: z.array(AbbildungSchema).optional(),
});

// https://zod.dev/compile seit Zod 4.5
export const BuchNeuSchema = z
    .compile(
        BuchSchema.omit({
            id: true,
            version: true,
        }),
    )
    .readonly();

export const BuchUpdateSchema = z
    .compile(
        BuchSchema.omit({
            id: true,
            version: true,
            titel: true,
            abbildungen: true,
        }),
    )
    .readonly();

export const BuchUpdateGraphQLSchema = z
    .compile(
        BuchSchema.omit({ titel: true, abbildungen: true })
            .partial()
            .required({ id: true, version: true }),
    )
    .readonly();

export type BuchNeuType = z.infer<typeof BuchNeuSchema>;
export type BuchUpdateType = z.infer<typeof BuchUpdateSchema>;
