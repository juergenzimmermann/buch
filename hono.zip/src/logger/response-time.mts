// Copyright (C) 2026 - present Juergen Zimmermann, Hochschule Karlsruhe
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program. If not, see <https://www.gnu.org/licenses/>.

import { type Context, type Next } from 'hono';
import { defineMiddleware } from 'hono/factory';
import { getConfig } from '../config/config.mts';
import { getLogger } from './logger.mts';

const logger = getLogger('responseTime', 'func');

const config = await getConfig();
const { hasTemporal } = config.server;

/**
 * Middleware für Hono, um vor dem Abschicken eines Response dessen Antwortzeit
 * und den Statuscode zu protokollieren.
 * @author [Jürgen Zimmermann](mailto:Juergen.Zimmermann@h-ka.de)
 */
// https://hono.dev/docs/guides/middleware
export const responseTime = defineMiddleware(async (c: Context, next: Next) => {
    // https://nodejs.org/en/blog/release/v26.0.0#temporal-api
    // https://tc39.es/proposal-temporal
    // https://github.com/tc39/proposal-temporal
    // https://developer.mozilla.org/de/docs/Web/JavaScript/Reference/Global_Objects/Temporal

    if (hasTemporal) {
        const start = Temporal.Now.instant().epochMilliseconds;
        await next(); // oxlint-disable-line node/callback-return
        const duration = Temporal.Now.instant().epochMilliseconds - start;
        logger.debug('Response time: %d ms, %d', duration, c.res.status);
        return;
    }

    // TODO https://github.com/docker-hardened-images/catalog/issues/542
    const temporalPolyFill = await import('temporal-polyfill');
    const start = temporalPolyFill.Temporal.Now.instant().epochMilliseconds;
    await next(); // oxlint-disable-line node/callback-return
    const duration = temporalPolyFill.Temporal.Now.instant().epochMilliseconds - start;
    logger.debug('Response time: %d ms, %d', duration, c.res.status);
});
