// Copyright (C) 2024 - present Juergen Zimmermann, Hochschule Karlsruhe
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program. If not, see <https://www.gnu.org/licenses/>.

import { getConfig } from '../config/config.mts';
import { getLogger } from '../logger/logger.mts';

const config = await getConfig();
const { clientId, clientSecret, host, https, port, realm } = config.keycloak;

const schema = https ? 'https' : 'http';
const accessTokenUrl = `${schema}://${host}:${port}/realms/${realm}/protocol/openid-connect/token`;

const CONTENT_TYPE = 'Content-Type';
const X_WWW_FORM_URLENCODED = 'application/x-www-form-urlencoded';
const POST = 'POST';

/** Typdefinition für Eingabedaten zu einem Token. */
export type TokenData = {
    readonly username: string | undefined;
    readonly password: string | undefined;
};

const headers: Headers = new Headers();
headers.append(CONTENT_TYPE, X_WWW_FORM_URLENCODED);

const logger = getLogger('keycloak-service');

// Logging der Rollen: wird auf Client-Seite benoetigt
// { ..., "azp": "javascript-client", "exp": ..., "resource_access": { "javascript-client": { "roles": ["admin"] } ...}
// azp = authorized party
const logPayload = (responseBody: unknown) => {
    if (
        !logger.isLevelEnabled('debug') ||
        responseBody === null ||
        typeof responseBody !== 'object' ||
        !Object.hasOwn(responseBody, 'access_token')
    ) {
        return;
    }

    const { access_token } = responseBody as { access_token: string };
    // Payload ist der mittlere Teil zwischen 2 Punkten und mit Base64 codiert
    const [, payloadStr] = access_token.split('.');

    // Base64 decodieren
    if (typeof payloadStr !== 'string') {
        return;
    }
    const payloadDecoded = atob(payloadStr);

    // JSON-Objekt fuer Payload aus dem decodierten String herstellen

    const payload = JSON.parse(payloadDecoded);
    const { azp, exp, resource_access } = payload;
    logger.debug('logPayload: exp=%s', exp);
    const { roles } = resource_access[azp];

    logger.debug('logPayload: roles=%o', roles);
};

export const token = async ({ username, password }: TokenData) => {
    logger.debug('token: username=%s', username);
    if (typeof username !== 'string' || typeof password !== 'string') {
        return;
    }

    // https://www.keycloak.org/docs-api/latest/rest-api
    // https://stackoverflow.com/questions/62683482/keycloak-rest-api-call-to-get-access-token-of-a-user-through-admin-username-and
    // https://stackoverflow.com/questions/65714161/keycloak-generate-access-token-for-a-user-with-keycloak-admin
    const body = new URLSearchParams({
        username,
        password,
        grant_type: 'password',
        client_id: clientId,
        client_secret: clientSecret,
    });

    logger.debug('token: path=%s', accessTokenUrl);
    logger.debug('token: body=%s', body);
    logger.debug('token: headers=%o', headers);
    let response: Response;
    try {
        response = await fetch(accessTokenUrl, {
            method: POST,
            body,
            headers,
        });
    } catch (err) {
        logger.warn('Fehler beim Zugriff auf Keycloak: %o', err as object);
        return;
    }

    const { status } = response;
    if (status !== 200) {
        logger.warn('Fehler beim Netzwerkzugriff auf Keycloak. Statuscode: %d', status);
        logger.warn('Fehler beim Netzwerkzugriff auf Keycloak. Statuscode: %d', status);
        logger.warn('Fehler beim Netzwerkzugriff auf Keycloak. Statuscode: %d', status);
        return;
    }

    const responseBody = await response.json();
    logPayload(responseBody);
    logger.debug('token: responseBody=%o', responseBody);
    return responseBody;
};
